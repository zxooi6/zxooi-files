# PWFusion_AS3935_I2C
![SEN-39001 FRONT](http://www.playingwithfusion.com/include/getimg.php?imgid=1104)
![SEN-39001 ISO](http://www.playingwithfusion.com/include/getimg.php?imgid=1105)

Arduino I2C Library for AS3935 Lightning Sensor. Designed to use antenna calibration (capacitance) value provided with the board. 
Example file hardware descripion is designed to work with Playing With Fusion breakout board SEN-39001, currently R01. Hardware details can be found on the <a href="http://www.playingwithfusion.com/productview.php?pdid=22">SEN-39001 Product Page</a>

Questions? Feel free to <a href="http://www.playingwithfusion.com/contactus.php">contact us!</a>
